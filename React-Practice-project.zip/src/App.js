import "./App.css";
import Loaders from "./components/Loaders";
// import ColorPicker from "./components/ColorPicker";
// import IdleTimerContainer from "./components/IdleTimerContainer";

function App() {
  return (
    <div className="App">
      {/* <IdleTimerContainer /> */}
      {/* <ColorPicker /> */}
      <Loaders />
    </div>
  );
}

export default App;
