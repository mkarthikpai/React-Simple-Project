import React, { useState } from "react";
import { ChromePicker } from "react-color";

function ColorPicker() {
  const [color, setColor] = useState("#fff");
  const [showColorPicker, setshowColorPicker] = useState(false);
  return (
    <div>
      <button
        onClick={() =>
          setshowColorPicker((showColorPicker) => !showColorPicker)
        }
      >
        {showColorPicker ? "Close color picker" : "Pick color"}
      </button>
      {showColorPicker && (
        <ChromePicker
          color={color}
          onChange={(updatedColor) => setColor(updatedColor.hex)}
        />
      )}
      <h2>You Picked {color}</h2>
    </div>
  );
}

export default ColorPicker;
