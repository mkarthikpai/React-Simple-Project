import React from "react";

import { BounceLoader, BarLoader, BeatLoader } from "react-spinners";

function Loaders() {
  return (
    <div>
      <BounceLoader size={25} color="red" loading />
      <BarLoader loading />
      <BeatLoader loading />
    </div>
  );
}

export default Loaders;
